
spatialExtent = [100,100,100];
R_normal = 15;
sig_normal = 1.5*4/R_normal;

res = 0.8:0.05:1.2;

energies = [];
energiesPos = [];


% for i = 1:length(res)
%     
%     sig = sig_normal*res(i);
%     R = R_normal/res(i);
%     gridSize = round(spatialExtent./res(i));
%     
%     AM = metricGPUGet_Alcubierre(0,1,R,sig,gridSize);
%     Z = met2den(AM);
%     energies(i,:,:) = den2en(Z);
%     energiesPos(i) = den2enPos(Z);
% end



startingRes = 0.65;
scalingFactor = 1.1;
res = [];
res(1) = startingRes;
for i = 1:10
    sig = sig_normal*res(i);
    R = R_normal/res(i);
    gridSize = round(spatialExtent./res(i));
    
    AM = metricGPUGet_Alcubierre(0,1,R,sig,gridSize);
    Z = met2den(AM);
    energies(i,:,:) = den2en(Z);
    energiesPos(i) = den2enPos(Z);
    res(i+1) = res(i)*scalingFactor;
end
res(length(res)) = [];


figure()
plot(res,energiesPos);
figure()
plot(res,energies(:,1,1))
figure()
plot(res,energies(:,2,2))
figure()
plot(res,energies(:,3,3))
figure()
plot(res,energies(:,4,4))
figure()
plot(res,energies(:,1,2))