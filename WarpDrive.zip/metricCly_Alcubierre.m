% dtdt        = (vs^2*sinh(2*R*sigma)^2)/(tanh(R*sigma)^2*(cosh(2*R*sigma) + cosh(2*sigma*(r^2 + z^2 - 2*z*zs + zs^2)^(1/2)))^2) - 1
% dzdz        = 1
% drdr        = 1
% dpdp        = r^2
% dtdz = dzdt = -(2*vs*(cosh(2*R*sigma) + 1))/(cosh(2*R*sigma) + cosh(2*sigma*(r^2 + z^2 - 2*z*zs + zs^2)^(1/2)))
% dtdr = drdt = 0
% dtdp = dpdt = 0
% dzdr = drdz = 0
% dzdp = dpdz = 0
% drdp = dpdr = 0









